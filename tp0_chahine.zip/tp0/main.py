from tp0.util import saisir_entier
from arithmetique import est_pair, somme
n: int = saisir_entier()
if not est_pair(n):
    n +=1
print(f"Somme de 0 `a {n} = {somme(n)}")