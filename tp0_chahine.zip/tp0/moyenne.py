def moyenne(a:int,b:int):
    return (a+b)/2
print(f"{moyenne(4,5)} \n{moyenne(11,14)} \n{moyenne(18,15)} \n{moyenne(20,15)} \n")