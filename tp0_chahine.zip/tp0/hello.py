text: str = 'Bonjour'
word: str = 'le monde'
if text == 'Bonjour':
    word = "0o7" # chiffre 0 (z´ero), lettre 'o' et chiffre 7 (sept)
text += ' ' + word
print(text)


print(f'Dissection de la cha^ıne de caract`eres {repr(text)} :')
for i, c in enumerate(text):
    print(f"{i} \t {c}")
exit()


