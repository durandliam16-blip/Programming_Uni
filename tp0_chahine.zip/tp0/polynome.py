def f(x:int)->int:
    return 2*pow(x,2)-x+1
x=int(input("Saisir x  :\n"))
print(f"la valeur finale : {f(x)}")
