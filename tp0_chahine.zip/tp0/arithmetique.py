def somme(n: int) -> int:
    return n*(n+1)//2

def est_divisible_par(n: int,k:int):
    if n%k==0:
        return True
    else:
        return False



def est_pair(a:int):
    return est_divisible_par(a,2)




def est_compris_dans(a: int, b: int, c: int) -> bool:

    if b <= c:
        return b <= a <= c
    else:
        # Si b > c, on inverse pour que ça fonctionne dans tous les cas
        return c <= a <= b


if __name__ == '__main__':
    print(somme(3))
    print(est_divisible_par(12, 4))
    print(est_pair(2))
    print(est_pair(4))
    print(est_pair(3))
    print(est_pair(7))
    print(est_compris_dans(3, 3, 5))   # a = b → True
    print(est_compris_dans(4, 3, 5))   # b < a < c → True
    print(est_compris_dans(5, 3, 5))   # a = c → True
    print(est_compris_dans(6, 3, 5))   # a > c → Falsetation
    pass
