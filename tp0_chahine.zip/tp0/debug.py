u: int = 27
while u != 1:
    if u%2:
        u=3*u+1
    else:
        u//=2
print('La conjecture de Syracuse est v´erifi´ee !')

#Conjencture de Syracuse, le resultat final est toujours de 1, donc on met une condition d'arret à u=1
# pour pouvoir sortir de la boucle infinie

#lorsque on met u=1, ça va afficher 1->4->2->1->4->2->1