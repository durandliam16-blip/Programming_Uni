with open("data_inventaire_prevert.txt", 'r')as infile:
    data=infile.read()


poeme = data.replace(";", "\n")
#print(poeme)

lignes = poeme.split("\n")

print(lignes)

lignes_num = []
numero = 1
for ligne in lignes:
    if ligne=="":
        pass
    else:
        if numero<10:
            lignes_num.append("0"+str(numero) + ". " + ligne.strip())
        else:
            lignes_num.append(str(numero) + ". " + ligne.strip())
        numero += 1

with open("mes-resultats.txt", "w", encoding="utf-8") as f:
    f.write("\n".join(lignes_num))

with open("mes-resultats.txt", "r", encoding="utf-8") as f1:
    d=f1.read()
print(d)







