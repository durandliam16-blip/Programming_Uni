# Configuration du modèle
MODEL = "llama3.2:3b"

# Codes couleurs pour le terminal (Pédagogie visuelle)
class Colors:
    SYSTEM = '\033[95m'    # Messages système
    BLUE = '\033[94m'      # Pensées de l'IA
    GREEN = '\033[92m'     # Observations (Retour du système)
    YELLOW = '\033[93m'    # Actions décidées
    RED = '\033[91m'       # Erreurs
    MAGENTA = '\033[95m'   # Entrée utilisateur
    ENDC = '\033[0m'
    BOLD = '\033[1m'
