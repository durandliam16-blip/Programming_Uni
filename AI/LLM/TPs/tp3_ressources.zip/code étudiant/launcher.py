import asyncio
import sys
import os
import ollama
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client
from config import MODEL, Colors
from client import runClient


async def run():
    # On calcule le chemin absolu vers server.py pour éviter les erreurs "File not found"
    script_dir = os.path.dirname(os.path.abspath(__file__))
    server_script = os.path.join(script_dir, "server.py")
    
    # On force l'utilisation de l'interpréteur Python actuel
    python_exe = sys.executable

    print(f"   -> Serveur cible : {server_script}")

    # Configuration du lancement du serveur
    server_params = StdioServerParameters(
        command=python_exe,
        args=[server_script],
        # Important sur Windows pour l'encodage
        env={**os.environ, "PYTHONUTF8": "1"} 
    )

    await runClient(server_params)

if __name__ == "__main__":
    # --- FIX WINDOWS ---
    if sys.platform.startswith('win'):
        asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())

    try:
        asyncio.run(run())

    # --- GESTION DES ERREURS (particularité : les exceptions sont groupées) ---
    except Exception as root_error:        
        # 1) fonction pour aplatir les ExceptionGroup
        def get_all_errors(exc):
            errors = []
            if isinstance(exc, BaseExceptionGroup):
                for e in exc.exceptions:
                    errors.extend(get_all_errors(e))
            else:
                errors.append(exc)
            return errors

        # 2) récupération de la liste de toutes erreurs
        real_errors = get_all_errors(root_error)
        
        # détection des types d'erreurs
        ollama_error = next((e for e in real_errors if isinstance(e, ollama.ResponseError)), None)
        conn_error = next((e for e in real_errors if isinstance(e, ConnectionError) or "Connection refused" in str(e)), None)
        keyboard_error = next((e for e in real_errors if isinstance(e, KeyboardInterrupt)), None)
        eof_error = next((e for e in real_errors if isinstance(e, EOFError)), None)

        # 3) Affichage du diagnostic
        if ollama_error:
            # Cas 1 : Erreur Ollama (400, 500...)
            print(f"\n{Colors.RED}-> ERREUR OLLAMA DÉTECTÉE ({ollama_error.status_code}){Colors.ENDC}")
            
            if ollama_error.status_code == 400 and "tools" in str(ollama_error):
                print(f"{Colors.YELLOW}👉 DIAGNOSTIC : Le modèle  refuse les outils.")
                print("   Solution : Mettez à jour le 'Modelfile' avec le template '{{ .Tools }}'.")
                print(f"   (Voir instructions du TP pour le patch Modelfile){Colors.ENDC}")
            else:
                print(f"   Message : {ollama_error.error}")
        
        elif conn_error:
            # Cas 2 : Ollama éteint
            print(f"\n{Colors.RED}-> IMPOSSIBLE DE JOINDRE OLLAMA{Colors.ENDC}")
            print(f"   Vérifiez que le serveur tourne : 'ollama serve'")

        elif keyboard_error or eof_error:
            # Cas 2b : Interruption clavier détectée dans un ExceptionGroup
            print("\n👋 Arrêt demandé. Au revoir !")

        else:
            # Cas 3 : Autre plantage (Code python, syntaxe...)
            print(f"\n{Colors.RED}-> ERREUR D'EXÉCUTION (ExceptionGroup){Colors.ENDC}")
            print("   Détail des erreurs rencontrées :")
            for i, err in enumerate(real_errors, 1):
                print(f"   {i}. {type(err).__name__}: {err}")

        sys.exit(1)
