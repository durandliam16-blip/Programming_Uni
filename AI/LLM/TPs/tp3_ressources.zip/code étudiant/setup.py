import os

# Chemin absolu du dossier courant
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
LOG_DIR = os.path.join(BASE_DIR, "logs_simulation")

def create_dummy_logs():
    if not os.path.exists(LOG_DIR):
        os.makedirs(LOG_DIR)
    
    # system.log
    path_sys = os.path.join(LOG_DIR, "system.log")
    with open(path_sys, "w", encoding="utf-8") as f:
        # Simuler 200 logs système réalistes et variés (au moins 20) avec des niveaux d'erreur différents et des probabilités normales sur un système classique
        for i in range(200):
            import random
            levels = ["INFO", "WARNING", "ERROR", "DEBUG", "CRITICAL"]
            info_messages = [
                "Démarrage du système réussi.",
                "Connexion réseau établie.",
                "Mise à jour des paquets terminée.",
                "Sauvegarde automatique effectuée.",
                "Nouvel utilisateur créé.",
                "Service web démarré.",
                "Analyse antivirus terminée.",
                "Configuration du pare-feu mise à jour.",
                "Espace disque suffisant.",
                "Synchronisation de l'heure réussie."
                ]
            warning_messages = [
                "Utilisation élevée du CPU détectée.",
                "Espace disque faible sur /dev/sda1.",
                "Tentative de connexion SSH échouée.",
                "Mise à jour du système en attente.",
                "Problème de latence réseau détecté.",
                "Erreur de lecture du fichier de configuration.",
                "Service de messagerie temporairement indisponible.",
                "Problème de permission sur le dossier /var/log.",
                "Erreur de synchronisation NTP.",
                "Problème de connexion à la base de données."
                ]
            error_messages = [
                "Échec du démarrage du service web.",
                "Perte de connexion réseau.",
                "Échec de la mise à jour des paquets.",
                "Corruption détectée dans la base de données.",
                "Erreur d'authentification utilisateur.",
                "Panne matérielle détectée sur le disque dur.",
                "Erreur de segmentation dans le processus X.",
                "Échec de la sauvegarde des données.",
                "Timeout lors de la connexion au serveur distant.",
                "Erreur de configuration du pare-feu."
                ]
            debug_messages = [
                "Variable x initialisée à 42.",
                "Fonction foo() appelée avec les paramètres a=1, b=2.",
                "Réponse du serveur reçue en 120ms.",
                "Cache vidé avec succès.",
                "Thread de fond démarré.",
                "Connexion à la base de données établie.",
                "Lecture du fichier de configuration terminée.",
                "Session utilisateur créée avec l'ID 12345.",
                "Données sérialisées en JSON.",
                "Processus enfant lancé avec le PID 6789."
                ]
            critical_messages = [
                "Panne totale du système détectée.",
                "Corruption majeure de la base de données.",
                "Violation de sécurité détectée.",
                "Échec critique du matériel serveur.",
                "Perte de données irréversible.",
                "Attaque DDoS en cours.",
                "Erreur fatale dans le noyau du système.",
                "Compromission du compte administrateur.",
                "Défaillance du système de sauvegarde.",
                "Erreur critique du système de fichiers.",
                "Intrusion détectée sur le réseau."
                ]
            messages = [info_messages, warning_messages, error_messages, debug_messages, critical_messages]
            level_number = random.choices(range(5), weights=[50, 20, 15, 10, 5])[0]
            message = random.choice(messages[level_number])
            f.write(f"{levels[level_number]}: {message}\n")
    
    # access.log
    path_acc = os.path.join(LOG_DIR, "access.log")
    with open(path_acc, "w", encoding="utf-8") as f:
        # Simuler quelques accès random (ip, url) avec des urls fictives parmis les plus courantes
        # et avec des dates (au format apache) cohérentes (progressives) générées aléatoirement
        date = 1672531200  # 1er Jan 2023
        for _ in range(500):
            ip = f"{192}.{os.urandom(1)[0]}.{os.urandom(1)[0]}.{os.urandom(1)[0]}"
            url = os.urandom(1)[0] % 5
            if url == 0:
                url_str = "/index.html"
            elif url == 1:
                url_str = "/login"
            elif url == 2:
                url_str = "/dashboard"
            elif url == 3:
                url_str = "/settings"
            else:
                url_str = "/api/data"
            date += os.urandom(1)[0] % 300  # Ajouter entre 0 et 5 minutes
            str_date = f"01/Jan/2023:{(date // 3600) % 24:02}:{(date // 60) % 60:02}:{date % 60:02} +0000"
            f.write(f'{ip} - - [{str_date}] "GET {url_str} HTTP/1.1" 200\n')

    print(f"✅ Logs générés dans : {LOG_DIR}")

if __name__ == "__main__":
    create_dummy_logs()
