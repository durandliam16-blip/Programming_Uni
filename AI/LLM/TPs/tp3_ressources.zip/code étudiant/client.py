import ollama
from mcp import ClientSession
from mcp.client.stdio import stdio_client
from config import MODEL, Colors
import os

os.environ['NO_PROXY'] = 'localhost,127.0.0.1,::1'

client = ollama.Client(host = 'http://127.0.0.1:11434')

async def runClient(server_params):
    # Connexion au serveur MCP
    async with stdio_client(server_params) as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()

            # Découverte des outils disponibles
            #TODO: découverte des outils MCP
            tools_list = []
            print(f"{Colors.YELLOW}  Outils découverts : {[t.name for t in tools_list.tools]}{Colors.ENDC}")

            # Conversion pour Ollama
            ollama_tools = []
            for tool in tools_list.tools:
                #TODO: conversion de chaque outil MCP en outil Ollama
                json_tool = {}
                ollama_tools.append(json_tool)

            # On initialise l'historique avec une instruction stricte
            messages = []
            # messages = [{
            #     'role': 'system', 
            #     'content': (
            #         "Tu es un assistant technique connecté à un serveur MCP. "
            #         "Tes outils sont ta seule façon d'interagir avec le système. "
            #         "Si l'utilisateur demande quelque chose qui nécessite un outil (comme voir les logs), "
            #         "N'EXPLIQUE RIEN. Utilise l'outil directement."
            #     )
            # }]
            
            print("\n-> Assistant DevOps prêt. (Tapez 'exit' pour quitter)")

            while True:
                # Gestion propre de l'encodage d'entrée sur Windows
                try:
                    user_input = input(f"\n{Colors.MAGENTA}Vous : {Colors.ENDC}")
                except UnicodeDecodeError:
                    print(f"{Colors.RED}-> Erreur d'encodage clavier. Essayez sans accents.{Colors.ENDC}")
                    continue

                if user_input.lower() in ["exit", "quit", "q"]:
                    break

                messages.append({'role': 'user', 'content': user_input})

                print(f"{Colors.BLUE}-> [IA] Réflexion en cours...{Colors.ENDC}")
                response = client.chat(
                    model=MODEL,
                    messages=messages,
                    tools=ollama_tools
                )
                print(f"{Colors.BLUE}-> [IA] Réponse reçue.{Colors.ENDC}")
                print(f"-> Contenu brut : {response['message']}")
                
                tool_calls = response['message'].get('tool_calls')

                if tool_calls:
                    messages.append(response['message'])
                    
                    for tool in tool_calls:
                        fn_name = tool['function']['name']
                        fn_args = tool['function']['arguments']
                        
                        print(f"{Colors.YELLOW}...  [IA] Exécution : {fn_name}({fn_args}){Colors.ENDC}")
                        
                        # Appel MCP
                        result = await session.call_tool(fn_name, arguments=fn_args)
                        
                        tool_output = result.content[0].text
                        print(f"{Colors.GREEN}... [Système] Retour : {tool_output.strip()[:100]}...{Colors.ENDC}")

                        messages.append({
                            'role': 'tool',
                            'content': tool_output,
                            'name': fn_name
                        })

                    final_response = client.chat(model=MODEL, messages=messages)
                    print(f"-> [IA] {final_response['message']['content']}")
                    messages.append(final_response['message'])

                else:
                    print(f"-> [IA] {response['message']['content']}")
                    messages.append(response['message'])
