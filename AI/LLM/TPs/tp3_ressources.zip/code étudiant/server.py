# Chemin compatible Windows/Linux
# On crée le dossier logs au même niveau que le script
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
LOG_DIR = os.path.join(BASE_DIR, "logs_simulation")


def list_logs() -> str:
    """Liste les logs.
    Args: pas d'arguments.
    Returns:
        str: Liste des fichiers log disponibles dans le dossier des logs."""
    try:
        if not os.path.exists(LOG_DIR):
            return "Erreur : Dossier logs introuvable."
        files = os.listdir(LOG_DIR)
        return str(files)
    except Exception as e:
        return f"Erreur système : {str(e)}"


def read_log_head(filename: str, lines: int = 5) -> str:
    """ Lit les N premieres lignes d'un fichier log .
        Args:
        filename (str): Nom du fichier log à lire (ex: 'system.log').
        lines (int): Nombre de lignes à lire depuis le début du fichier. Défaut à 5."""
    safe_filename = os.path.basename(filename)
    path = os.path.join(LOG_DIR, safe_filename)
    
    if not os.path.exists(path):
        return f"Erreur : Fichier '{safe_filename}' introuvable."
        
    try:
        content = []
        with open(path, 'r', encoding='utf-8') as f:
            for _ in range(lines):
                line = f.readline()
                if not line: break
                content.append(line)
        return "".join(content)
    except Exception as e:
        return f"Erreur lecture : {str(e)}"
