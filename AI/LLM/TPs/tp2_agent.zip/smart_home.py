# ==============================================================================
# Étape 1 : Conception de la Maison Domotique
# ==============================================================================

"""Le systeme physique que l'IA va controler."""
class SmartHome:
    def __init__(self):
        # État initial de la maison
        self.rooms = ["salon", "cuisine", "chambre"]
        self.state = {}
        for room in self.rooms:
            self.state[room] = False  # False = Éteint
        self.state["temperature"] = 19.5


    def get_light_state(self, room):
        """Retourne l'état de la lumière dans une pièce."""
        #TODO: Completer cette methode
        return f"TODO: retourner l'état de la lumière dans : {room}"


    def light_on(self, room):
        """Allume la lumière dans une pièce."""
        #TODO: Completer cette methode
        return f"TODO: retourner l'état de la lumière allumée dans : {room}"


    def light_off(self, room):
        """Éteint la lumière dans une pièce."""
        #TODO: Completer cette methode
        return f"TODO: retourner l'état de la lumière éteinte dans : {room}"


    def get_temperature(self, room):
        """Retourne la température de la pièce spécifiée."""
        #TODO: Completer cette methode
        return f"TODO: retourner la température actuelle dans : {room}"