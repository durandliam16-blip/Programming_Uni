import time
import ollama
import numpy as np
import faiss
import sys
import os

os.environ['NO_PROXY'] = 'localhost,127.0.0.1,::1'

client = ollama.Client(host = 'http://127.0.0.1:11434')

# --- CONFIGURATION ---
# Modèle pour comprendre le sens du texte (Embeddings)
EMBED_MODEL = "nomic-embed-text" 
# Modèle pour générer la réponse (Chat)
CHAT_MODEL = "gemma3:4b" 

# ==============================================================================
# PHASE 2 : Vectorisation d'une base documentaire
# ==============================================================================

# ------------------------------------------------------------------------------
# Étape 3 : Préparation de la base documentaire

def get_embedding(text):
    """Génère le vecteur d'un texte via l'API Ollama."""
    try:
        response = client.embeddings(model=EMBED_MODEL, prompt=text)
        return response['embedding']
    except Exception as e:
        print(f"Erreur Ollama (vérifiez que 'ollama serve' tourne et que le modèle {EMBED_MODEL} est installé) : {e}")
        sys.exit(1)


def generate_embeddings(docs):
    """Génère les embeddings pour une liste de documents."""
    embeddings = []
    #TODO: gérer les embeddings pour chaque document
    #fake embeddings pour l'exemple
    for _ in docs:
        embeddings.append(np.random.rand(768).astype('float32'))
    return embeddings


# ------------------------------------------------------------------------------
# Étape 4 : Indexation naïve par similarité cosinus

def cosine_similarity(v1, v2):
    """
    Calcule la similarité cosinus manuellement.
    Formule : (A . B) / (||A|| * ||B||)
    Retourne une valeur entre -1 (opposés) et 1 (identiques).
    """
    cosine_sim = 0.0
    #TODO: calculer la similarité cosinus entre v1 et v2
    return cosine_sim


def naive_search(query, embeddings, docs, nb_results=3):
    """Recherche naïve par similarité cosinus."""
    # Les résultats seront des tuples (score, document)
    results = []
    #TODO: vectoriser la requête et calculer la similarité avec chaque document ; trier et retourner les meilleurs résultats
    return results


# ------------------------------------------------------------------------------
# Étape 5 : Indexation Industrielle avec Faiss

def faiss_index(embeddings_np):
    """Crée un index FAISS à partir des embeddings."""
    index = None
    #TODO: créer l'index FAISS, normaliser les vecteurs pour la similarité cosinus, ajouter les vecteurs à l'index
    return index


def faiss_search(query, index, docs, nb_results=3):
    """Recherche avec Faiss."""
    # Les résultats seront des tuples (score, document)
    results = []
    #TODO: vectoriser la requête, normaliser le vecteur, effectuer la recherche dans l'index, récupérer les documents correspondants
    return results


# ==============================================================================
# Phase 3 : Génération Augmentée avec Gemma 3
# ==============================================================================

# ------------------------------------------------------------------------------
# Étape 6 : Interrogation de Gemma 3 avec le contexte

def rag_query(user_query, index, docs):
    """Interroge Gemma 3 avec le contexte récupéré."""
    # Récupération du contexte via Faiss
    #TODO: récupérer les k documents les plus pertinents via faiss_search et générer le prompt
    system_prompt = f"""
"""

    try:
        response = client.chat(
            model=CHAT_MODEL, 
            messages=[{'role': 'user', 'content': system_prompt}]
        )
        print("*** RÉPONSE DE GEMMA 3 ***")
        print("-" * 40)
        print(response['message']['content'])
        print("-" * 40)

    except Exception as e:
        print(f"Erreur lors de l'appel à Gemma : {e}")



# ==============================================================================
# PHASE 3 : Bonus - RAG Multimodal avec Gemma 3
# ==============================================================================

# ------------------------------------------------------------------------------
# Étape 7 : Le Concept : Le "Pont Sémantique"

def generate_description_for_image(image_path):
    """Utilise Gemma 3 pour décrire une image."""
    description = ""
    #TODO: utiliser l'API Ollama pour générer une description textuelle de l'image
    return description

def generate_multimodal_embeddings(docs):
    """Génère les embeddings pour une liste de documents (texte + images)."""
    embeddings = []
    #TODO: pour chaque document, si c'est une image, générer une description avec generate_description_for_image, sinon inclure le texte, puis vectoriser
    return embeddings


def multimodal_rag_query(user_query, index, docs):
    """Interroge Gemma 3 avec le contexte multimodal récupéré."""
    #TODO: similaire à rag_query, mais gérer les documents qui sont des images
    pass


# ==============================================================================
# MAIN
# ==============================================================================

if __name__ == "__main__":
    # --- DONNÉES SIMULÉES (Documentation Technique) ---
    knowledge_base = [
        "La Turbo-Encabulator 3000 utilise un stator logarithmique pré-activé.",
        "Pour redémarrer le système d'urgence, maintenez le bouton rouge pendant 5 secondes, puis tournez la clé bleue.",
        "L'erreur 404 sur cette machine indique une surchauffe du condensateur fluxionnel principal.",
        "La maintenance des roulements à billes doit être effectuée tous les 150 cycles par un technicien certifié de niveau 2.",
        "Le voltage nominal d'entrée est de 220V, mais l'appareil tolère des fluctuations entre 210V et 240V.",
        "En cas de fuite de liquide réfrigérant (couleur verte), évacuez la zone immédiatement.",
        "Le module Wi-Fi se connecte uniquement sur la bande 2.4GHz avec le protocole WPA2.",
        "L'interface tactile peut se bloquer si l'opérateur porte des gants en latex non conducteurs."
    ]


    # Génération des embeddings
    print("\n--- Génération des embeddings pour la base documentaire ---")
    start_time_vectorisation = time.time()
    embeddings = generate_embeddings(knowledge_base)
    print(f"\t-> Embeddings générés pour {len(embeddings)} documents.")

    print(f"\t-> Conversion des embeddings en tableau numpy...")
    embeddings_np = np.array(embeddings)
    end_time_vectorisation = time.time()

    print(f"\t-> Taille du tableau numpy : {embeddings_np.shape}")
    print(f"\t-> Dimension des embeddings : {embeddings_np.shape[1]}")


    user_query = "Comment redémarrer la machine en cas d'urgence ?"

    # Indexation naïve
    print(f"\n--- Recherche naïve pour la question : '{user_query}' ---")
    start_time_manual_search = time.time()
    manual_results = naive_search(user_query, embeddings_np, knowledge_base, 3)
    end_time_manual_search = time.time()

    print(f"\t-> Résultats de la recherche naïve :")
    for score, doc in manual_results:
        print(f"\t   [Score: {score:.4f}] {doc}")


    # Indexation avec Faiss
    print(f"\n--- Création de l'index Faiss ---")
    start_time_faiss_index = time.time()
    index = faiss_index(embeddings_np)
    end_time_faiss_index = time.time()


    # Recherche avec Faiss
    print(f"\n--- Recherche optimisée avec FAISS pour la question : '{user_query}' ---")
    start_time_faiss_search = time.time()
    faiss_results = faiss_search(user_query, index, knowledge_base, 3)
    end_time_faiss_search = time.time()

    print(f"\t-> Résultats de la recherche FAISS :")
    for dist, doc in faiss_results:
        print(f"\t   [Distance: {dist:.4f}] {doc}")


    # Intégration du RAG avec Gemma 3
    print(f"\n--- Intégration RAG avec Gemma 3 pour la question : '{user_query}' ---")
    start_time_rag = time.time()
    rag_query(user_query, index, knowledge_base)
    end_time_rag = time.time()


    # RAG Multimodal avec Gemma 3 (Bonus)
    print(f"\n--- RAG Multimodal avec Gemma 3 (Bonus) ---")
    knowledge_base.append("images/turbo-encabulator_3000.png")
    # Génération des embeddings pour la nouvelle entrée (texte + image)
    print("-> Génération des embeddings multimodaux pour la base documentaire...")
    start_time_multimodal_vectorisation = time.time()
    multimodal_embeddings = generate_multimodal_embeddings(knowledge_base)
    end_time_multimodal_vectorisation = time.time()
    # Création de l'index Faiss multimodal
    print("-> Création de l'index Faiss multimodal...")
    start_time_multimodal_faiss_index = time.time()
    multimodal_index = faiss_index(np.array(multimodal_embeddings))
    end_time_multimodal_faiss_index = time.time()
    # Requête multimodale
    print("-> Requête multimodale...")
    start_time_multimodal_rag = time.time()
    multimodal_rag_query("Décris le fonctionnement de la Turbo-Encabulator 3000.", multimodal_index, knowledge_base)
    end_time_multimodal_rag = time.time()

    # Résumé des temps d'exécution
    print(f"\n\n####################################################\nRésumé des temps d'exécution :")
    print(f" - Vectorisation des documents : {end_time_vectorisation - start_time_vectorisation:.2f} secondes")
    print(f" - Recherche naïve : {end_time_manual_search - start_time_manual_search:.2f} secondes")
    print(f" - Création de l'index FAISS : {end_time_faiss_index - start_time_faiss_index:.2f} secondes")
    print(f" - Recherche FAISS : {end_time_faiss_search - start_time_faiss_search:.2f} secondes")
    print(f" - RAG avec Gemma 3 : {end_time_rag - start_time_rag:.2f} secondes")
    print("### Mode Multimodal ###")
    print(f" - Vectorisation Multimodale : {end_time_multimodal_vectorisation - start_time_multimodal_vectorisation:.2f} secondes")
    print(f" - Création de l'index FAISS Multimodal : {end_time_multimodal_faiss_index - start_time_multimodal_faiss_index:.2f} secondes")
    print(f" - RAG Multimodal avec Gemma 3 : {end_time_multimodal_rag - start_time_multimodal_rag:.2f} secondes")
